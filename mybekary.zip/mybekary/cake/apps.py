from django.apps import AppConfig


class CakeConfig(AppConfig):
    name = 'cake'
