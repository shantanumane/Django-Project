from django.shortcuts import render
from .models import allorders
from django.core.mail import EmailMessage
# Create your views here.

def home(request):
    if request.method =='GET':
        return render(request,'home.html')
    if request.method=="POST":
        try:
            name=request.POST.get('name')
            email=request.POST.get('email')
            product=request.POST.get('product')
            category=request.POST.get('category')
            quantity=request.POST.get('quantity')
            mobile=request.POST.get('mobile')
            address=request.POST.get('address')
            
            message ="Thank {nm} for your order.\nYour order for: {prod}.\n Quantity:{quant}.\nCategory:{cat} .\n Our team will contact you soon.  .".format(nm=name,prod=product,quant=quantity,cat=category)
            email = EmailMessage('myBekary Order Confirmed', message, to=[email])
            email.send()

            
            message2="You have new order.\nCustomer name:{nm}.\nYour order for: {prod}.\n Quantity:{quant}.\nCategory:{cat} .\n Our team will contact you soon.  .".format(nm=name,prod=product,quant=quantity,cat=category)
            email2='djangobudget@gmail.com'
            email = EmailMessage('New order received', message2, to=[email2])
            email.send()
            obj=allorders()
            obj.name=name
            obj.email=request.POST.get('email')
            obj.product=product
            obj.category=category
            obj.quantity=quantity
            obj.mobile=mobile
            obj.address=address
            obj.save()
            
            return render(request,'home.html',{'msg':'Order placed successfully. Check your email.','tag':'success'})
        except Exception:
            return render(request,'home.html',{'msg':'Error: order not placed','tag':'danger'})


from .login import Username,Password
   
listid=[]
listid.append(Username)
listid.append(Password)


def table(request):
    order_list=Orders.objects.all()
    return render(request,'table.html',{'list':order_list})

def owner(request):
    if request.method =='GET':
        return render(request,'owner.html')
    if request.method=='POST':
        try:
            uname=request.POST.get("username")
            passw=request.POST.get('password')
            
            if(uname==listid[0] and passw==listid[1]):
                order_list=allorders.objects.all()
                return render(request,'table.html',{ 'list':order_list})
            else:
                return render(request,'owner.html',{'msg':'Note:This is for only Company employee.Login failed. ','tag':'success'})

        except Exception:
            return render(request,'owner.html')
            



def deleteOrder(request,id):
    allorders.objects.filter(id=id).delete()
    order_list=allorders.objects.all()
    return render(request,'table.html',{ 'list':order_list})


def singleapp(request,id):
    single_list=allorders.objects.get(id=id)
    print(single_list.name)
    return render(request,'singleapp.html',{'data':single_list})

def menu(request):
    return render(request,'menu.html')

def about(request):
    return render(request,'about.html')

def contact(request):
    if request.method =='GET':
        return render(request,'contacts.html')
    if request.method=='POST':
        try:
            firstname=request.POST.get("firstname")
            lastname=request.POST.get('lastname')
            areacode=request.POST.get('areacode')
            telnum=request.POST.get('telnum')
            emailid=request.POST.get('emailid')
            feedback=request.POST.get('feedback')
            message="Thank {name} for your Feedback".format(name=firstname)
            email = EmailMessage('Feedback Received.', message, to=[emailid])
            email.send()
            myemail="djangobudget@gmail.com"
            message="Feedback received from {name}.\n Customer No: {tel}\n Customer Email: {email}.\n Feedback Message:{msg}".format(name=firstname,tel=telnum,email=emailid,msg=feedback)
            email = EmailMessage('Check new feedback.', message, to=[myemail])
            email.send()
            
            return render(request,'contacts.html')
        

        except Exception:
            return render(request,'contacts.html')