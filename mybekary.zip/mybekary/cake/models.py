from django.db import models

# Create your models here.
class allorders(models.Model):
    name=models.CharField(max_length=80)
    email=models.EmailField(max_length=40)
    product=models.CharField(max_length=100)
    category=models.CharField(max_length=100)
    quantity=models.CharField(max_length=100)
    mobile=models.CharField(max_length=20)
    address=models.CharField(max_length=250)

